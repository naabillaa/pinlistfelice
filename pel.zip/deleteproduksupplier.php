<?php
include "config.php"; // Mengimpor file konfigurasi database

// Pastikan parameter namaproduk pelanggan tersedia
if (isset($_GET['namaproduk'])) {
    // Ambil nilai parameter namaproduk dari URL
    $namaproduk = $_GET['namaproduk'];

    // Buat query SQL untuk mengambil nama file foto produk yang terkait dengan pelanggan
    $query = "SELECT fotoproduk FROM produksupplier WHERE namaproduk = '$namaproduk'";
    
    // Eksekusi query untuk mendapatkan nama file foto produk
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $fotoProduk = $row['fotoproduk'];

    // Buat query SQL untuk menghapus pelanggan berdasarkan namaproduk
    $deleteQuery = "DELETE FROM produksupplier WHERE namaproduk = '$namaproduk'";
    
    // Eksekusi query penghapusan
    if (mysqli_query($conn, $deleteQuery)) {
        // Jika penghapusan berhasil, hapus juga file foto produk terkait secara permanen
        $targetDir = "produk/"; // Direktori penyimpanan file foto produk
        $targetFilePath = $targetDir . $fotoProduk;
        
        // Hapus file jika ada
        if (file_exists($targetFilePath)) {
            unlink($targetFilePath);
        }

        // Tampilkan pesan sukses dan arahkan kembali ke halaman produk.php
        echo "<script>alert('Pelanggan berhasil dihapus.'); window.location='dataproduksupplier.php';</script>";
    } else {
        // Jika terjadi kesalahan saat menjalankan query, tampilkan pesan kesalahan dan kembalikan pengguna ke halaman sebelumnya
        echo "<script>alert('Error: " . mysqli_error($conn) . "'); window.history.back();</script>";
    }
    
    // Tutup koneksi ke database
    mysqli_close($conn);
} else {
    // Jika parameter namaproduk tidak tersedia, tampilkan pesan kesalahan dan kembalikan pengguna ke halaman sebelumnya
    echo "<script>alert('Parameter namaproduk pelanggan tidak tersedia.'); window.history.back();</script>";
}
?>


