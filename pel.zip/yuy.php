<?php
// Include file konfigurasi database
include 'config.php';

// Mulai session
session_start();

// Redirect ke halaman login jika session username tidak di-set
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit(); // Hentikan eksekusi script setelah redirect
}

// Inisialisasi variabel untuk pesan feedback dan errors
$pesan = '';

// Check if form is submitted
if (isset($_POST['submit'])) {
    // Collect form data
    $kodepelanggan = $_POST['kodepelanggan'];
    $namaperusahaan = $_POST['namaperusahaan'];
    $klasifikasi = $_POST['klasifikasi'];
    $alamatperusahaan = $_POST['alamatperusahaan'];
    $alamatperusahaan2 = $_POST['alamatperusahaan2'];
    $alamatpengiriman = $_POST['alamatpengiriman'];
    $alamatpengiriman2 = $_POST['alamatpengiriman2'];
    $kontakperson = $_POST['kontakperson'];
    $kontakperson2 = $_POST['kontakperson2'];
    $email = $_POST['email'];
    $website = $_POST['website'];
    $npwp = $_POST['npwp'];
    $sales = $_POST['sales'];
    $catatan = $_POST['catatan'];
    $tanggalupdate = $_POST['tanggalupdate'];

    // Folder tujuan untuk menyimpan file proposal
    $targetDir = 'proposal/';

    // Handle File Upload for proposal
    $proposalFileName = '';
    if (isset($_FILES['proposal']) && $_FILES['proposal']['error'] === UPLOAD_ERR_OK) {
        $proposalFileName = $_FILES['proposal']['name'];
        $proposalFilePath = $targetDir . $proposalFileName;

        // Pindahkan file ke folder tujuan
        if (move_uploaded_file($_FILES['proposal']['tmp_name'], $proposalFilePath)) {
            echo "File proposal berhasil diunggah.";
        } else {
            echo "Gagal mengunggah file proposal.";
        }
    } else {
        echo "Error: Terjadi masalah saat mengunggah file proposal.";
    }

    // Handle File Upload for proposal2
    $proposal2FileName = '';
    if (isset($_FILES['proposal2']) && $_FILES['proposal2']['error'] === UPLOAD_ERR_OK) {
        $proposal2FileName = $_FILES['proposal2']['name'];
        $proposal2FilePath = $targetDir . $proposal2FileName;

        // Pindahkan file ke folder tujuan
        if (move_uploaded_file($_FILES['proposal2']['tmp_name'], $proposal2FilePath)) {
            echo "File proposal2 berhasil diunggah.";
        } else {
            echo "Gagal mengunggah file proposal2.";
        }
    } else {
        echo "Error: Terjadi masalah saat mengunggah file proposal2.";
    }

    // Handle File Upload for proposal3
    $proposal3FileName = '';
    if (isset($_FILES['proposal3']) && $_FILES['proposal3']['error'] === UPLOAD_ERR_OK) {
        $proposal3FileName = $_FILES['proposal3']['name'];
        $proposal3FilePath = $targetDir . $proposal3FileName;

        // Pindahkan file ke folder tujuan
        if (move_uploaded_file($_FILES['proposal3']['tmp_name'], $proposal3FilePath)) {
            echo "File proposal3 berhasil diunggah.";
        } else {
            echo "Gagal mengunggah file proposal3.";
        }
    } else {
        echo "Error: Terjadi masalah saat mengunggah file proposal3.";
    }

    // Example SQL insert query
    $sql = "INSERT INTO pelanggan (kodepelanggan, namaperusahaan, klasifikasi, alamatperusahaan, alamatperusahaan2, alamatpengiriman, alamatpengiriman2, kontakperson, kontakperson2, email, website, npwp, proposal, proposal2, proposal3, sales, catatan, tanggalupdate) 
            VALUES ('$kodepelanggan', '$namaperusahaan', '$klasifikasi', '$alamatperusahaan', '$alamatperusahaan2', '$alamatpengiriman', '$alamatpengiriman2', '$kontakperson', '$kontakperson2', '$email', '$website', '$npwp', '$proposalFileName', '$proposal2FileName', '$proposal3FileName', '$sales', '$catatan', '$tanggalupdate')";

    // Execute the insert query
    if (mysqli_query($conn, $sql)) {
        $pesan = "Data berhasil disimpan.";
    } else {
        $pesan = "Gagal menyimpan data: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Upload Proposal</title>
</head>
<body>
    <h2>Form Upload Proposal</h2>
    <?php echo $pesan; ?>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="kodepelanggan">Kode Pelanggan:</label><br>
        <input type="text" id="kodepelanggan" name="kodepelanggan" required><br><br>
        
        <label for="namaperusahaan">Nama Perusahaan:</label><br>
        <input type="text" id="namaperusahaan" name="namaperusahaan" required><br><br>
        
        <label for="klasifikasi">Klasifikasi:</label><br>
        <input type="text" id="klasifikasi" name="klasifikasi" required><br><br>
        
        <label for="alamatperusahaan">Alamat Perusahaan:</label><br>
        <textarea id="alamatperusahaan" name="alamatperusahaan" required></textarea><br><br>
        
        <label for="alamatperusahaan2">Alamat Perusahaan 2:</label><br>
        <textarea id="alamatperusahaan2" name="alamatperusahaan2"></textarea><br><br>
        
        <label for="alamatpengiriman">Alamat Pengiriman:</label><br>
        <textarea id="alamatpengiriman" name="alamatpengiriman" required></textarea><br><br>
        
        <label for="alamatpengiriman2">Alamat Pengiriman 2:</label><br>
        <textarea id="alamatpengiriman2" name="alamatpengiriman2"></textarea><br><br>
        
        <label for="kontakperson">Kontak Person:</label><br>
        <input type="text" id="kontakperson" name="kontakperson" required><br><br>
        
        <label for="kontakperson2">Kontak Person 2:</label><br>
        <input type="text" id="kontakperson2" name="kontakperson2"><br><br>
        
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        
        <label for="website">Website:</label><br>
        <input type="text" id="website" name="website"><br><br>
        
        <label for="npwp">NPWP:</label><br>
        <input type="text" id="npwp" name="npwp"><br><br>
        
        <label for="proposal">File Proposal 1:</label><br>
        <input type="file" id="proposal" name="proposal" required><br><br>
        
        <label for="proposal2">File Proposal 2:</label><br>
        <input type="file" id="proposal2" name="proposal2"><br><br>
        
        <label for="proposal3">File Proposal 3:</label><br>
        <input type="file" id="proposal3" name="proposal3"><br><br>
        
        <label for="sales">Sales:</label><br>
        <input type="text" id="sales" name="sales" required><br><br>
        
        <label for="catatan">Catatan:</label><br>
        <textarea id="catatan" name="catatan"></textarea><br><br>
        
        <label for="tanggalupdate">Tanggal Update:</label><br>
        <input type="date" id="tanggalupdate" name="tanggalupdate" required><br><br>
        
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>
